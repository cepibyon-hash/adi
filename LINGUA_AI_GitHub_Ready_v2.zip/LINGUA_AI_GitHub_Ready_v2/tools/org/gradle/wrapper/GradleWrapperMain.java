package org.gradle.wrapper;

import java.io.IOException;
import java.net.URI;
import java.net.URL;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.nio.file.StandardCopyOption;
import java.util.ArrayList;
import java.util.List;
import java.util.Properties;
import java.util.zip.ZipEntry;
import java.util.zip.ZipInputStream;

/** Minimal Gradle distribution bootstrapper used when the official wrapper JAR cannot be fetched here. */
public final class GradleWrapperMain {
    public static void main(String[] args) throws Exception {
        Path root = findProjectRoot(Paths.get(System.getProperty("user.dir")).toAbsolutePath());
        Path propertiesPath = root.resolve("gradle/wrapper/gradle-wrapper.properties");
        Properties properties = new Properties();
        try (var input = Files.newInputStream(propertiesPath)) {
            properties.load(input);
        }
        String distributionUrl = properties.getProperty("distributionUrl");
        if (distributionUrl == null || distributionUrl.isBlank()) {
            throw new IllegalStateException("distributionUrl tidak ditemukan pada gradle-wrapper.properties");
        }
        URI uri = URI.create(distributionUrl.replace("\\:", ":"));
        String zipName = Paths.get(uri.getPath()).getFileName().toString();
        String distributionName = zipName.replaceFirst("-bin\\.zip$", "").replaceFirst("-all\\.zip$", "");
        String baseName = zipName.substring(0, zipName.length() - 4);
        String gradleHome = System.getenv("GRADLE_USER_HOME");
        Path cacheRoot = (gradleHome == null || gradleHome.isBlank())
                ? Paths.get(System.getProperty("user.home"), ".gradle")
                : Paths.get(gradleHome);
        Path installDir = cacheRoot.resolve("wrapper/dists").resolve(distributionName + "-bin").resolve("lingua-ai");
        Path gradleDir = installDir.resolve(distributionName);
        Path executable = gradleDir.resolve(isWindows() ? "bin/gradle.bat" : "bin/gradle");

        if (!Files.isRegularFile(executable)) {
            Files.createDirectories(installDir);
            Path zip = installDir.resolve(baseName + ".zip");
            if (!Files.isRegularFile(zip) || Files.size(zip) == 0) {
                System.out.println("Mengunduh Gradle dari " + distributionUrl);
                URL url = uri.toURL();
                try (var stream = url.openStream()) {
                    Files.copy(stream, zip, StandardCopyOption.REPLACE_EXISTING);
                }
            }
            unzip(zip, installDir);
        }
        if (!Files.isRegularFile(executable)) {
            throw new IllegalStateException("Executable Gradle tidak ditemukan: " + executable);
        }

        List<String> command = new ArrayList<>();
        if (isWindows()) {
            command.add("cmd.exe");
            command.add("/c");
        }
        command.add(executable.toString());
        for (String arg : args) command.add(arg);
        Process process = new ProcessBuilder(command).directory(root.toFile()).inheritIO().start();
        System.exit(process.waitFor());
    }

    private static Path findProjectRoot(Path start) {
        Path current = start;
        while (current != null) {
            if (Files.isRegularFile(current.resolve("gradle/wrapper/gradle-wrapper.properties"))) return current;
            current = current.getParent();
        }
        throw new IllegalStateException("Tidak menemukan gradle/wrapper/gradle-wrapper.properties");
    }

    private static void unzip(Path zip, Path destination) throws IOException {
        try (ZipInputStream input = new ZipInputStream(Files.newInputStream(zip))) {
            ZipEntry entry;
            while ((entry = input.getNextEntry()) != null) {
                Path output = destination.resolve(entry.getName()).normalize();
                if (!output.startsWith(destination.normalize())) throw new IOException("Path ZIP tidak aman");
                if (entry.isDirectory()) {
                    Files.createDirectories(output);
                } else {
                    Files.createDirectories(output.getParent());
                    Files.copy(input, output, StandardCopyOption.REPLACE_EXISTING);
                }
                input.closeEntry();
            }
        }
    }

    private static boolean isWindows() {
        return System.getProperty("os.name", "").toLowerCase().contains("win");
    }
}
