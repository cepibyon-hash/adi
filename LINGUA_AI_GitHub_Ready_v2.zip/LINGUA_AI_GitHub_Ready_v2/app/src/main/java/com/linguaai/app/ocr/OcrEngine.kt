package com.linguaai.app.ocr

import android.graphics.Bitmap
import android.graphics.Rect
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.text.TextRecognition
import com.google.mlkit.vision.text.TextRecognizer
import com.google.mlkit.vision.text.chinese.ChineseTextRecognizerOptions
import com.google.mlkit.vision.text.devanagari.DevanagariTextRecognizerOptions
import com.google.mlkit.vision.text.japanese.JapaneseTextRecognizerOptions
import com.google.mlkit.vision.text.korean.KoreanTextRecognizerOptions
import com.google.mlkit.vision.text.latin.TextRecognizerOptions
import com.google.mlkit.nl.languageid.LanguageIdentification
import com.google.mlkit.nl.languageid.LanguageIdentificationOptions
import com.google.mlkit.nl.languageid.LanguageIdentifier
import com.linguaai.app.data.OcrRegion
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.async
import kotlinx.coroutines.awaitAll
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.tasks.await

class OcrEngine {
    private val recognizers: List<TextRecognizer> = listOf(
        TextRecognition.getClient(TextRecognizerOptions.DEFAULT_OPTIONS),
        TextRecognition.getClient(ChineseTextRecognizerOptions.Builder().build()),
        TextRecognition.getClient(JapaneseTextRecognizerOptions.Builder().build()),
        TextRecognition.getClient(KoreanTextRecognizerOptions.Builder().build()),
        TextRecognition.getClient(DevanagariTextRecognizerOptions.Builder().build())
    )

    private val languageIdentifier: LanguageIdentifier = LanguageIdentification.getClient(
        LanguageIdentificationOptions.Builder()
            .setConfidenceThreshold(0.30f)
            .build()
    )

    suspend fun recognize(bitmap: Bitmap): List<OcrRegion> = coroutineScope {
        val input = InputImage.fromBitmap(bitmap, 0)
        val outputs = recognizers.map { recognizer ->
            async(Dispatchers.Default) { runCatching { recognizer.process(input).await() }.getOrNull() }
        }.awaitAll()

        val collected = mutableListOf<OcrRegion>()
        outputs.filterNotNull().forEachIndexed { engineIndex, result ->
            result.textBlocks.forEachIndexed { blockIndex, block ->
                val text = block.text.trim()
                val box = block.boundingBox ?: return@forEachIndexed
                if (text.length < 2 || box.width() < 4 || box.height() < 4) return@forEachIndexed
                val candidate = OcrRegion("local-$engineIndex-$blockIndex", text, Rect(box))
                val duplicate = collected.any { existing ->
                    existing.text.equals(candidate.text, ignoreCase = true) && overlapRatio(existing.bounds, candidate.bounds) > 0.45f
                }
                if (!duplicate) collected += candidate
            }
        }
        collected
    }

    suspend fun detectLanguage(text: String): String {
        if (text.isBlank()) return "und"
        return runCatching { languageIdentifier.identifyLanguage(text).await() }.getOrDefault("und")
    }

    fun close() {
        recognizers.forEach { runCatching { it.close() } }
        runCatching { languageIdentifier.close() }
    }

    private fun overlapRatio(a: Rect, b: Rect): Float {
        val intersection = Rect(a)
        if (!intersection.intersect(b)) return 0f
        val intersectionArea = intersection.width().toFloat() * intersection.height().toFloat()
        val unionArea = (a.width() * a.height() + b.width() * b.height() - intersectionArea).coerceAtLeast(1f)
        return intersectionArea / unionArea
    }
}
