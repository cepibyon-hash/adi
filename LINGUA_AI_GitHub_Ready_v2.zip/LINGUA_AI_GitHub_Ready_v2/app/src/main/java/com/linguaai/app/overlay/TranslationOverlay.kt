package com.linguaai.app.overlay

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Rect
import android.graphics.Typeface
import android.graphics.drawable.ColorDrawable
import android.os.Handler
import android.os.Looper
import android.view.Gravity
import android.view.View
import android.view.WindowManager
import android.text.Layout
import android.text.StaticLayout
import android.text.TextPaint
import com.linguaai.app.data.OverlayTranslation
import kotlin.math.max
import kotlin.math.min

class TranslationOverlayController(private val context: Context) {
    private val windowManager = context.getSystemService(Context.WINDOW_SERVICE) as WindowManager
    private val mainHandler = Handler(Looper.getMainLooper())
    private var overlayView: TranslationOverlayView? = null

    fun show() {
        mainHandler.post {
            if (overlayView != null) return@post
            val view = TranslationOverlayView(context)
            val params = WindowManager.LayoutParams(
                WindowManager.LayoutParams.MATCH_PARENT,
                WindowManager.LayoutParams.MATCH_PARENT,
                WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                    WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE or
                    WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or
                    WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS or
                    WindowManager.LayoutParams.FLAG_SECURE,
                android.graphics.PixelFormat.TRANSLUCENT
            ).apply {
                gravity = Gravity.TOP or Gravity.START
                x = 0
                y = 0
            }
            view.background = ColorDrawable(Color.TRANSPARENT)
            overlayView = view
            runCatching { windowManager.addView(view, params) }
                .onFailure { overlayView = null }
        }
    }

    fun update(translations: List<OverlayTranslation>, frameWidth: Int, frameHeight: Int) {
        val safeWidth = frameWidth.coerceAtLeast(1)
        val safeHeight = frameHeight.coerceAtLeast(1)
        val safeItems = translations.map {
            it.copy(bounds = Rect(it.bounds))
        }
        mainHandler.post { overlayView?.setTranslations(safeItems, safeWidth, safeHeight) }
    }

    fun clear() {
        mainHandler.post { overlayView?.setTranslations(emptyList(), 1, 1) }
    }

    fun hide() {
        mainHandler.post {
            overlayView?.let { view -> runCatching { windowManager.removeView(view) } }
            overlayView = null
        }
    }
}

private class TranslationOverlayView(context: Context) : View(context) {
    private var translations: List<OverlayTranslation> = emptyList()
    private var sourceWidth: Int = 1
    private var sourceHeight: Int = 1
    private val density = resources.displayMetrics.density
    private val backgroundPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.argb(238, 18, 34, 56)
        style = Paint.Style.FILL
    }
    private val borderPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.argb(210, 105, 200, 255)
        style = Paint.Style.STROKE
        strokeWidth = 1.1f * density
    }
    private val textPaint = TextPaint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.WHITE
        typeface = Typeface.create("sans-serif-medium", Typeface.NORMAL)
    }

    init {
        setLayerType(LAYER_TYPE_SOFTWARE, null)
        importantForAccessibility = IMPORTANT_FOR_ACCESSIBILITY_NO
    }

    fun setTranslations(items: List<OverlayTranslation>, width: Int, height: Int) {
        translations = items
        sourceWidth = width.coerceAtLeast(1)
        sourceHeight = height.coerceAtLeast(1)
        invalidate()
    }

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        if (translations.isEmpty() || width == 0 || height == 0) return
        val scaleX = width.toFloat() / sourceWidth.toFloat()
        val scaleY = height.toFloat() / sourceHeight.toFloat()
        val minWidth = 56f * density
        val maxWidth = width * 0.82f
        val corner = 7f * density
        val padX = 7f * density
        val padY = 4f * density

        translations.forEach { item ->
            val original = item.bounds
            val left = (original.left * scaleX).coerceIn(0f, width.toFloat() - 1f)
            val top = (original.top * scaleY).coerceIn(0f, height.toFloat() - 1f)
            val originalWidth = max(minWidth, original.width() * scaleX)
            val availableWidth = max(minWidth, min(maxWidth, width - left - 4f * density))
            val boxWidth = min(originalWidth, availableWidth).coerceAtLeast(minWidth.coerceAtMost(availableWidth))
            val fontSize = (original.height() * scaleY * 0.52f).coerceIn(12f * density, 19f * density)
            textPaint.textSize = fontSize
            val contentWidth = (boxWidth - padX * 2).toInt().coerceAtLeast((40f * density).toInt())
            val layout = StaticLayout.Builder
                .obtain(item.translatedText, 0, item.translatedText.length, textPaint, contentWidth)
                .setAlignment(Layout.Alignment.ALIGN_NORMAL)
                .setIncludePad(false)
                .setLineSpacing(0f, 1.0f)
                .build()
            val boxHeight = max(original.height() * scaleY, layout.height + padY * 2)
            val rect = android.graphics.RectF(
                left - 2f * density,
                top - 2f * density,
                min(width.toFloat(), left + boxWidth + 2f * density),
                min(height.toFloat(), top + boxHeight + 2f * density)
            )
            canvas.drawRoundRect(rect, corner, corner, backgroundPaint)
            canvas.drawRoundRect(rect, corner, corner, borderPaint)
            canvas.save()
            canvas.translate(left + padX, top + padY)
            layout.draw(canvas)
            canvas.restore()
        }
    }
}
