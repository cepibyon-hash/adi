#!/usr/bin/env sh
set -eu
ROOT="$(CDPATH= cd -- "$(dirname -- "$0")" && pwd)"
if [ -z "${ANDROID_HOME:-}" ] && [ -z "${ANDROID_SDK_ROOT:-}" ] && [ ! -f "$ROOT/local.properties" ]; then
  echo "Android SDK belum terdeteksi melalui ANDROID_HOME/ANDROID_SDK_ROOT atau local.properties." >&2
  echo "Instal Android Studio dan Android SDK Platform 35, lalu jalankan kembali." >&2
  exit 2
fi
cd "$ROOT"
./gradlew :app:assembleDebug
printf '\nAPK output: %s/app/build/outputs/apk/debug/app-debug.apk\n' "$ROOT"
