package com.linguaai.app.util

import android.graphics.Bitmap
import android.media.Image
import java.nio.ByteBuffer

object BitmapUtils {
    fun imageToBitmap(image: Image): Bitmap? {
        val plane = image.planes.firstOrNull() ?: return null
        val buffer: ByteBuffer = plane.buffer
        val pixelStride = plane.pixelStride
        val rowStride = plane.rowStride
        val width = image.width
        val height = image.height
        val rowPadding = rowStride - pixelStride * width
        val paddedWidth = width + rowPadding / pixelStride
        val padded = Bitmap.createBitmap(paddedWidth, height, Bitmap.Config.ARGB_8888)
        buffer.rewind()
        padded.copyPixelsFromBuffer(buffer)
        if (paddedWidth == width) return padded
        val cropped = Bitmap.createBitmap(padded, 0, 0, width, height)
        padded.recycle()
        return cropped
    }

    fun signature(bitmap: Bitmap): Long {
        val sampleWidth = 32
        val sampleHeight = 18
        val sample = Bitmap.createScaledBitmap(bitmap, sampleWidth, sampleHeight, true)
        val pixels = IntArray(sampleWidth * sampleHeight)
        sample.getPixels(pixels, 0, sampleWidth, 0, 0, sampleWidth, sampleHeight)
        sample.recycle()
        var hash = 1125899906842597L
        for (pixel in pixels) {
            val gray = (((pixel shr 16) and 0xff) * 3 + ((pixel shr 8) and 0xff) * 6 + (pixel and 0xff)) / 10
            hash = hash * 31 + gray
        }
        return hash
    }
}
