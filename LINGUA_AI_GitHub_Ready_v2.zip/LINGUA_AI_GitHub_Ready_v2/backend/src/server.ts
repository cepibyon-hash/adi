import 'dotenv/config';
import express, { Request, Response, NextFunction } from 'express';
import helmet from 'helmet';
import rateLimit from 'express-rate-limit';
import { z } from 'zod';
import { TranslationServiceClient } from '@google-cloud/translate';
import { ImageAnnotatorClient } from '@google-cloud/vision';

const app = express();
const port = Number(process.env.PORT ?? 8787);
const projectId = process.env.GOOGLE_CLOUD_PROJECT;
const apiToken = process.env.LINGUA_API_TOKEN;
const maxImageBytes = Number(process.env.MAX_IMAGE_BYTES ?? 6_500_000);

app.disable('x-powered-by');
app.use(helmet());
app.use(express.json({ limit: '10mb' }));
app.use(rateLimit({ windowMs: 15 * 60 * 1000, limit: 180, standardHeaders: 'draft-7', legacyHeaders: false }));

const translationClient = new TranslationServiceClient();
const visionClient = new ImageAnnotatorClient();

const translateSchema = z.object({
  targetLanguage: z.string().min(2).max(10).default('id'),
  items: z.array(z.object({
    id: z.string().min(1).max(100),
    text: z.string().min(1).max(4000),
    sourceLanguage: z.string().min(2).max(10).optional()
  })).min(1).max(45)
});

const ocrSchema = z.object({
  imageBase64: z.string().min(1),
  imageWidth: z.number().int().positive().max(12000),
  imageHeight: z.number().int().positive().max(12000)
});

function authenticate(req: Request, res: Response, next: NextFunction): void {
  if (!apiToken) return next();
  const supplied = req.header('authorization')?.replace(/^Bearer\s+/i, '');
  if (!supplied || supplied !== apiToken) {
    res.status(401).json({ error: 'Unauthorized: token API tidak valid.' });
    return;
  }
  next();
}

function requireProject(res: Response): boolean {
  if (projectId) return true;
  res.status(503).json({ error: 'GOOGLE_CLOUD_PROJECT belum dikonfigurasi pada server.' });
  return false;
}

app.get('/health', (_req, res) => {
  res.json({ service: 'LINGUA AI Backend', status: 'ok', targetLanguage: 'id' });
});

app.post('/v1/translate-batch', authenticate, async (req, res) => {
  if (!requireProject(res)) return;
  const parsed = translateSchema.safeParse(req.body);
  if (!parsed.success) {
    res.status(400).json({ error: 'Format permintaan terjemahan tidak valid.', details: parsed.error.flatten() });
    return;
  }

  try {
    const targetLanguageCode = parsed.data.targetLanguage || 'id';
    const translations = await Promise.all(parsed.data.items.map(async (item) => {
      const sourceLanguageCode = item.sourceLanguage?.split('-')[0];
      if (sourceLanguageCode === targetLanguageCode) {
        return { id: item.id, translatedText: item.text, detectedSourceLanguage: sourceLanguageCode };
      }
      const [result] = await translationClient.translateText({
        parent: `projects/${projectId}/locations/global`,
        contents: [item.text],
        mimeType: 'text/plain',
        targetLanguageCode,
        ...(sourceLanguageCode && sourceLanguageCode !== 'und'
          ? { sourceLanguageCode }
          : {})
      });
      const translation = result.translations?.[0];
      return {
        id: item.id,
        translatedText: translation?.translatedText ?? item.text,
        detectedSourceLanguage: translation?.detectedLanguageCode ?? item.sourceLanguage ?? 'und'
      };
    }));
    res.json({ targetLanguage: targetLanguageCode, translations });
  } catch (error) {
    const message = error instanceof Error ? error.message : 'Translation provider error';
    console.error('[translate-batch]', message);
    res.status(502).json({ error: 'Layanan penerjemahan gagal memproses permintaan.' });
  }
});

app.post('/v1/ocr', authenticate, async (req, res) => {
  if (!requireProject(res)) return;
  const parsed = ocrSchema.safeParse(req.body);
  if (!parsed.success) {
    res.status(400).json({ error: 'Format permintaan OCR tidak valid.', details: parsed.error.flatten() });
    return;
  }

  try {
    const imageBuffer = Buffer.from(parsed.data.imageBase64, 'base64');
    if (imageBuffer.byteLength > maxImageBytes) {
      res.status(413).json({ error: 'Ukuran gambar melewati batas yang diizinkan.' });
      return;
    }
    const [result] = await visionClient.documentTextDetection({ image: { content: imageBuffer } });
    const annotation = result.fullTextAnnotation;
    const regions: Array<{ text: string; left: number; top: number; right: number; bottom: number }> = [];

    for (const page of annotation?.pages ?? []) {
      for (const block of page.blocks ?? []) {
        for (const paragraph of block.paragraphs ?? []) {
          const text = (paragraph.words ?? [])
            .map((word) => (word.symbols ?? []).map((symbol) => symbol.text ?? '').join(''))
            .join(' ')
            .trim();
          if (!text) continue;
          const vertices = paragraph.boundingBox?.vertices ?? [];
          if (vertices.length === 0) continue;
          const xs = vertices.map((vertex) => Number(vertex.x ?? 0));
          const ys = vertices.map((vertex) => Number(vertex.y ?? 0));
          const left = Math.max(0, Math.min(...xs));
          const top = Math.max(0, Math.min(...ys));
          const right = Math.min(parsed.data.imageWidth, Math.max(...xs));
          const bottom = Math.min(parsed.data.imageHeight, Math.max(...ys));
          regions.push({ text, left, top, right, bottom });
        }
      }
    }
    res.json({ regions });
  } catch (error) {
    const message = error instanceof Error ? error.message : 'Vision provider error';
    console.error('[ocr]', message);
    res.status(502).json({ error: 'Layanan OCR cloud gagal memproses gambar.' });
  }
});

app.use((error: unknown, _req: Request, res: Response, _next: NextFunction) => {
  console.error('[unhandled]', error);
  res.status(500).json({ error: 'Terjadi kesalahan internal pada server.' });
});

app.listen(port, () => {
  console.log(`LINGUA AI backend listening on :${port}`);
});
