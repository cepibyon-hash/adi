package com.linguaai.app.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Language
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Stop
import androidx.compose.material.icons.filled.Translate
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Divider
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.linguaai.app.data.AppPreferences

private val Navy = Color(0xFF0B1220)
private val CardNavy = Color(0xFF14243A)
private val Accent = Color(0xFF8BD8FF)
private val Muted = Color(0xFF9FB1C8)

@Composable
fun LinguaApp(
    preferences: AppPreferences,
    isRunning: Boolean,
    statusMessage: String,
    onStart: () -> Unit,
    onStop: () -> Unit
) {
    MaterialTheme(colorScheme = darkColorScheme(
        primary = Accent,
        onPrimary = Color(0xFF071321),
        secondary = Color(0xFF8FAED1),
        background = Navy,
        surface = CardNavy,
        onSurface = Color.White,
        onBackground = Color.White
    )) {
        Surface(modifier = Modifier.fillMaxSize(), color = Navy) {
            var backendUrl by remember { mutableStateOf(preferences.backendUrl) }
            var accessToken by remember { mutableStateOf(preferences.accessToken) }
            var cloudOcrEnabled by remember { mutableStateOf(preferences.cloudOcrEnabled) }
            var savedMessage by remember { mutableStateOf("Konfigurasi server belum disimpan.") }

            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .background(Brush.verticalGradient(listOf(Color(0xFF10213A), Navy, Color(0xFF080E19))))
                    .verticalScroll(rememberScrollState())
                    .padding(horizontal = 20.dp, vertical = 24.dp),
                verticalArrangement = Arrangement.spacedBy(16.dp)
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(
                        modifier = Modifier
                            .size(54.dp)
                            .background(Color(0xFF243F67), RoundedCornerShape(16.dp)),
                        contentAlignment = Alignment.Center
                    ) {
                        androidx.compose.material3.Icon(
                            imageVector = Icons.Filled.Translate,
                            contentDescription = "LINGUA AI",
                            tint = Accent,
                            modifier = Modifier.size(30.dp)
                        )
                    }
                    Spacer(Modifier.width(13.dp))
                    Column(modifier = Modifier.weight(1f)) {
                        Text("LINGUA AI", fontSize = 25.sp, fontWeight = FontWeight.Bold, color = Color.White)
                        Text("CONTINUOUS SCREEN TRANSLATOR", fontSize = 9.sp, letterSpacing = 1.2.sp, color = Accent)
                    }
                    Box(
                        modifier = Modifier
                            .background(if (isRunning) Color(0xFF174B3B) else Color(0xFF29364A), CircleShape)
                            .padding(horizontal = 11.dp, vertical = 6.dp)
                    ) {
                        Text(if (isRunning) "ACTIVE" else "READY", fontSize = 10.sp, fontWeight = FontWeight.Bold,
                            color = if (isRunning) Color(0xFF8CF0BD) else Muted)
                    }
                }

                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(22.dp),
                    colors = CardDefaults.cardColors(containerColor = Color(0xFF152C48))
                ) {
                    Column(Modifier.padding(18.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                        Text("Translate Everything.", fontSize = 22.sp, fontWeight = FontWeight.Bold, color = Color.White)
                        Text("Terjemahkan tulisan di layar menjadi Bahasa Indonesia secara otomatis.",
                            color = Color(0xFFC0D1E4), fontSize = 13.sp)
                        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            androidx.compose.material3.Icon(Icons.Filled.Language, null, tint = Accent, modifier = Modifier.size(18.dp))
                            Text("Auto Detect  →  Indonesia", color = Accent, fontWeight = FontWeight.SemiBold, fontSize = 12.sp)
                        }
                    }
                }

                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(20.dp),
                    colors = CardDefaults.cardColors(containerColor = CardNavy)
                ) {
                    Column(Modifier.padding(18.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                        Text("SCREEN TRANSLATOR", color = Muted, fontSize = 10.sp, fontWeight = FontWeight.Bold, letterSpacing = 1.1.sp)
                        Text(if (isRunning) "Penerjemah sedang berjalan" else "Penerjemah belum aktif",
                            color = Color.White, fontSize = 18.sp, fontWeight = FontWeight.SemiBold)
                        Text(statusMessage, color = Muted, fontSize = 12.sp)
                        Button(
                            onClick = if (isRunning) onStop else onStart,
                            modifier = Modifier.fillMaxWidth().height(52.dp),
                            shape = RoundedCornerShape(15.dp),
                            colors = ButtonDefaults.buttonColors(
                                containerColor = if (isRunning) Color(0xFF7B3440) else Accent,
                                contentColor = if (isRunning) Color.White else Color(0xFF071321)
                            )
                        ) {
                            androidx.compose.material3.Icon(
                                imageVector = if (isRunning) Icons.Filled.Stop else Icons.Filled.PlayArrow,
                                contentDescription = null
                            )
                            Spacer(Modifier.width(8.dp))
                            Text(if (isRunning) "STOP TRANSLATION" else "START TRANSLATION", fontWeight = FontWeight.Bold)
                        }
                    }
                }

                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(20.dp),
                    colors = CardDefaults.cardColors(containerColor = CardNavy)
                ) {
                    Column(Modifier.padding(18.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                        Text("KONFIGURASI SERVER", color = Muted, fontSize = 10.sp, fontWeight = FontWeight.Bold, letterSpacing = 1.1.sp)
                        OutlinedTextField(
                            value = backendUrl,
                            onValueChange = { backendUrl = it },
                            modifier = Modifier.fillMaxWidth(),
                            label = { Text("Backend HTTPS URL") },
                            placeholder = { Text("https://api.domain-anda.com") },
                            singleLine = true,
                            shape = RoundedCornerShape(13.dp)
                        )
                        OutlinedTextField(
                            value = accessToken,
                            onValueChange = { accessToken = it },
                            modifier = Modifier.fillMaxWidth(),
                            label = { Text("Access token (opsional sesuai backend)") },
                            singleLine = true,
                            visualTransformation = PasswordVisualTransformation(),
                            shape = RoundedCornerShape(13.dp)
                        )
                        Button(
                            onClick = {
                                preferences.backendUrl = backendUrl
                                preferences.accessToken = accessToken
                                savedMessage = if (backendUrl.startsWith("https://")) "Konfigurasi tersimpan." else "Masukkan URL backend HTTPS yang valid."
                            },
                            modifier = Modifier.fillMaxWidth(),
                            shape = RoundedCornerShape(12.dp)
                        ) { Text("SIMPAN KONFIGURASI") }
                        Text(savedMessage, color = Muted, fontSize = 11.sp)
                    }
                }

                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(20.dp),
                    colors = CardDefaults.cardColors(containerColor = CardNavy)
                ) {
                    Column(Modifier.padding(18.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                        Text("OCR HYBRID & PRIVASI", color = Muted, fontSize = 10.sp, fontWeight = FontWeight.Bold, letterSpacing = 1.1.sp)
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Column(Modifier.weight(1f)) {
                                Text("Izinkan OCR cloud sebagai cadangan", color = Color.White, fontWeight = FontWeight.SemiBold, fontSize = 13.sp)
                                Text("Jika OCR lokal tidak menemukan teks, screenshot dapat dikirim ke server OCR cloud.",
                                    color = Muted, fontSize = 11.sp)
                            }
                            Switch(
                                checked = cloudOcrEnabled,
                                onCheckedChange = {
                                    cloudOcrEnabled = it
                                    preferences.cloudOcrEnabled = it
                                }
                            )
                        }
                        Divider(color = Color(0xFF30445F))
                        Text("OCR lokal diproses di perangkat. Cloud OCR nonaktif secara default dan hanya berjalan setelah Anda mengaktifkannya.",
                            color = Muted, fontSize = 11.sp)
                    }
                }

                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(20.dp),
                    colors = CardDefaults.cardColors(containerColor = CardNavy)
                ) {
                    Column(Modifier.padding(18.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        Text("FITUR AKTIF", color = Muted, fontSize = 10.sp, fontWeight = FontWeight.Bold, letterSpacing = 1.1.sp)
                        FeatureLine("Continuous screen detection", "Pemeriksaan layar adaptif")
                        FeatureLine("Automatic language detection", "Bahasa sumber dikenali otomatis")
                        FeatureLine("Replace overlay", "Terjemahan menutupi teks sumber")
                        FeatureLine("Hybrid OCR", "OCR lokal dan cadangan cloud")
                        FeatureLine("Target language", "Bahasa Indonesia")
                    }
                }

                Text("LINGUA AI  •  Version 1.0.0", color = Color(0xFF71839B), fontSize = 10.sp,
                    modifier = Modifier.align(Alignment.CenterHorizontally).padding(bottom = 12.dp))
            }
        }
    }
}

@Composable
private fun FeatureLine(title: String, detail: String) {
    Row(modifier = Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
        Box(Modifier.size(7.dp).background(Accent, CircleShape))
        Spacer(Modifier.width(10.dp))
        Column(Modifier.weight(1f)) {
            Text(title, color = Color.White, fontSize = 12.sp, fontWeight = FontWeight.SemiBold)
            Text(detail, color = Muted, fontSize = 10.sp)
        }
    }
}
