package com.linguaai.app.data

import android.graphics.Bitmap
import android.util.Base64
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONArray
import org.json.JSONObject
import java.io.ByteArrayOutputStream
import java.util.concurrent.TimeUnit

class TranslationApi(private val preferences: AppPreferences) {
    private val client = OkHttpClient.Builder()
        .connectTimeout(15, TimeUnit.SECONDS)
        .readTimeout(35, TimeUnit.SECONDS)
        .writeTimeout(20, TimeUnit.SECONDS)
        .callTimeout(45, TimeUnit.SECONDS)
        .build()

    suspend fun translateBatch(items: List<TranslationRequestItem>): Map<String, String> = withContext(Dispatchers.IO) {
        if (items.isEmpty()) return@withContext emptyMap()
        val baseUrl = requireBackendUrl()
        val payload = JSONObject().apply {
            put("targetLanguage", "id")
            put("items", JSONArray().apply {
                items.forEach { item ->
                    put(JSONObject().apply {
                        put("id", item.id)
                        put("text", item.text)
                        if (item.sourceLanguage.isNotBlank() && item.sourceLanguage != "und") {
                            put("sourceLanguage", item.sourceLanguage)
                        }
                    })
                }
            })
        }
        val response = executeJson("$baseUrl/v1/translate-batch", payload)
        val translations = response.optJSONArray("translations") ?: JSONArray()
        buildMap {
            for (index in 0 until translations.length()) {
                val item = translations.optJSONObject(index) ?: continue
                val id = item.optString("id")
                val text = item.optString("translatedText")
                if (id.isNotBlank() && text.isNotBlank()) put(id, text)
            }
        }
    }

    suspend fun cloudOcr(bitmap: Bitmap): List<OcrRegion> = withContext(Dispatchers.IO) {
        val baseUrl = requireBackendUrl()
        val bytes = ByteArrayOutputStream().use { output ->
            bitmap.compress(Bitmap.CompressFormat.JPEG, 72, output)
            output.toByteArray()
        }
        val payload = JSONObject().apply {
            put("imageBase64", Base64.encodeToString(bytes, Base64.NO_WRAP))
            put("imageWidth", bitmap.width)
            put("imageHeight", bitmap.height)
        }
        val response = executeJson("$baseUrl/v1/ocr", payload)
        val array = response.optJSONArray("regions") ?: JSONArray()
        buildList {
            for (index in 0 until array.length()) {
                val item = array.optJSONObject(index) ?: continue
                val text = item.optString("text").trim()
                if (text.isBlank()) continue
                val left = item.optInt("left").coerceIn(0, bitmap.width)
                val top = item.optInt("top").coerceIn(0, bitmap.height)
                val right = item.optInt("right").coerceIn(left, bitmap.width)
                val bottom = item.optInt("bottom").coerceIn(top, bitmap.height)
                add(OcrRegion("cloud-$index", text, Rect(left, top, right, bottom)))
            }
        }
    }

    private fun requireBackendUrl(): String {
        val url = preferences.backendUrl.trim().trimEnd('/')
        require(url.startsWith("https://")) {
            "Alamat backend belum diatur atau belum menggunakan HTTPS. Buka Pengaturan LINGUA AI."
        }
        return url
    }

    private fun executeJson(url: String, payload: JSONObject): JSONObject {
        val builder = Request.Builder()
            .url(url)
            .post(payload.toString().toRequestBody("application/json; charset=utf-8".toMediaType()))
            .header("Accept", "application/json")
        preferences.accessToken.takeIf { it.isNotBlank() }?.let {
            builder.header("Authorization", "Bearer $it")
        }
        client.newCall(builder.build()).execute().use { response ->
            val body = response.body?.string().orEmpty()
            if (!response.isSuccessful) {
                val message = runCatching { JSONObject(body).optString("error") }.getOrNull()
                throw IllegalStateException(message?.takeIf { it.isNotBlank() } ?: "Backend gagal (${response.code}).")
            }
            return JSONObject(body)
        }
    }
}
