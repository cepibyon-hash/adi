package com.linguaai.app

import android.Manifest
import android.app.Activity
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.media.projection.MediaProjectionManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.runtime.mutableStateOf
import androidx.core.content.ContextCompat
import com.linguaai.app.data.AppPreferences
import com.linguaai.app.service.ScreenCaptureService
import com.linguaai.app.ui.LinguaApp

class MainActivity : ComponentActivity() {
    private lateinit var preferences: AppPreferences
    private val runningState = mutableStateOf(false)
    private val statusMessageState = mutableStateOf("Siap menerjemahkan layar.")

    private val captureLauncher = registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { result ->
        val data = result.data
        if (result.resultCode == Activity.RESULT_OK && data != null) {
            ScreenCaptureService.start(this, result.resultCode, data)
            runningState.value = true
            statusMessageState.value = "Memulai LINGUA AI..."
        } else {
            statusMessageState.value = "Izin screen capture dibatalkan."
        }
    }

    private val overlaySettingsLauncher = registerForActivityResult(ActivityResultContracts.StartActivityForResult()) {
        if (Settings.canDrawOverlays(this)) {
            continueStartFlow()
        } else {
            statusMessageState.value = "Izin overlay diperlukan agar terjemahan dapat tampil di atas aplikasi lain."
        }
    }

    private val notificationPermissionLauncher = registerForActivityResult(ActivityResultContracts.RequestPermission()) {
        requestScreenCapturePermission()
    }

    private val statusReceiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context?, intent: Intent?) {
            if (intent?.action != ScreenCaptureService.ACTION_STATUS) return
            runningState.value = intent.getBooleanExtra(ScreenCaptureService.EXTRA_RUNNING, false)
            statusMessageState.value = intent.getStringExtra(ScreenCaptureService.EXTRA_MESSAGE)
                ?: "Status LINGUA AI diperbarui."
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        preferences = AppPreferences(this)
        window.statusBarColor = android.graphics.Color.rgb(11, 18, 32)
        window.navigationBarColor = android.graphics.Color.rgb(11, 18, 32)
        setContent {
            LinguaApp(
                preferences = preferences,
                isRunning = runningState.value,
                statusMessage = statusMessageState.value,
                onStart = { startTranslation() },
                onStop = {
                    ScreenCaptureService.stop(this)
                    runningState.value = false
                    statusMessageState.value = "Penerjemah dihentikan."
                }
            )
        }
    }

    override fun onStart() {
        super.onStart()
        ContextCompat.registerReceiver(
            this,
            statusReceiver,
            IntentFilter(ScreenCaptureService.ACTION_STATUS),
            ContextCompat.RECEIVER_NOT_EXPORTED
        )
    }

    override fun onStop() {
        runCatching { unregisterReceiver(statusReceiver) }
        super.onStop()
    }

    private fun startTranslation() {
        if (!preferences.backendUrl.startsWith("https://")) {
            statusMessageState.value = "Atur URL backend HTTPS terlebih dahulu pada bagian Konfigurasi Server."
            return
        }
        if (!Settings.canDrawOverlays(this)) {
            val intent = Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName"))
            overlaySettingsLauncher.launch(intent)
            return
        }
        continueStartFlow()
    }

    private fun continueStartFlow() {
        if (Build.VERSION.SDK_INT >= 33 &&
            ContextCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS) != android.content.pm.PackageManager.PERMISSION_GRANTED
        ) {
            notificationPermissionLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
        } else {
            requestScreenCapturePermission()
        }
    }

    private fun requestScreenCapturePermission() {
        val manager = getSystemService(Context.MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
        captureLauncher.launch(manager.createScreenCaptureIntent())
    }
}
