package com.linguaai.app.data

import android.content.Context

class AppPreferences(context: Context) {
    private val prefs = context.getSharedPreferences("lingua_ai_settings", Context.MODE_PRIVATE)

    var backendUrl: String
        get() = prefs.getString(KEY_BACKEND_URL, "") ?: ""
        set(value) = prefs.edit().putString(KEY_BACKEND_URL, value.trim().trimEnd('/')).apply()

    var accessToken: String
        get() = prefs.getString(KEY_ACCESS_TOKEN, "") ?: ""
        set(value) = prefs.edit().putString(KEY_ACCESS_TOKEN, value.trim()).apply()

    var cloudOcrEnabled: Boolean
        get() = prefs.getBoolean(KEY_CLOUD_OCR, false)
        set(value) = prefs.edit().putBoolean(KEY_CLOUD_OCR, value).apply()

    var captureIntervalMs: Long
        get() = prefs.getLong(KEY_CAPTURE_INTERVAL, 2200L)
        set(value) = prefs.edit().putLong(KEY_CAPTURE_INTERVAL, value.coerceIn(1500L, 5000L)).apply()

    companion object {
        private const val KEY_BACKEND_URL = "backend_url"
        private const val KEY_ACCESS_TOKEN = "access_token"
        private const val KEY_CLOUD_OCR = "cloud_ocr_enabled"
        private const val KEY_CAPTURE_INTERVAL = "capture_interval_ms"
    }
}
