package com.linguaai.app.data

import android.graphics.Rect

data class OcrRegion(
    val id: String,
    val text: String,
    val bounds: Rect
)

data class TranslationRequestItem(
    val id: String,
    val text: String,
    val sourceLanguage: String
)

data class OverlayTranslation(
    val id: String,
    val originalText: String,
    val translatedText: String,
    val sourceLanguage: String,
    val bounds: Rect
)
