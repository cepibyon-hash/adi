# LINGUA AI — Android Screen Translator

LINGUA AI adalah proyek Android penerjemah layar berkelanjutan. Aplikasi menangkap layar setelah pengguna memberikan izin Android, menjalankan OCR lokal, mendeteksi bahasa, mengirim teks ke backend untuk diterjemahkan ke Bahasa Indonesia, lalu menggambar panel pengganti semi-transparan melalui overlay Android.

## Status paket ini

- Source project Android: tersedia.
- Source backend Node.js: tersedia.
- APK hasil kompilasi: belum tersedia dari lingkungan penyusunan ini karena Android SDK/Gradle tidak terpasang dan akses internet untuk mengunduh toolchain dibatasi. Tidak ada file APK palsu atau placeholder yang disertakan.
- Untuk menghasilkan APK, buka project ini di Android Studio yang memiliki Android SDK 35 dan jalankan `:app:assembleDebug`.

## Keputusan produk

| Pengaturan | Nilai |
|---|---|
| Nama | LINGUA AI |
| Platform | Android |
| Minimum Android | 8.0 / API 26 |
| Target SDK | 35 |
| Mode | Continuous screen translation |
| Tampilan | Replace overlay |
| OCR | Hybrid: ML Kit lokal + Google Cloud Vision fallback |
| Bahasa sumber | Otomatis |
| Bahasa tujuan | Indonesia (`id`) |
| Terjemahan | Google Cloud Translation API v3 |
| Prioritas | Balanced |

## Struktur project

```text
LINGUA-AI/
├── app/
│   ├── src/main/AndroidManifest.xml
│   └── src/main/java/com/linguaai/app/
│       ├── MainActivity.kt
│       ├── data/
│       ├── ocr/
│       ├── overlay/
│       ├── service/
│       ├── ui/
│       └── util/
├── backend/
│   ├── src/server.ts
│   ├── package.json
│   └── .env.example
├── build.gradle.kts
├── settings.gradle.kts
└── gradle.properties
```

## A. Menyiapkan backend

Backend wajib disiapkan sebelum tombol Start Translation digunakan. APK tidak menyimpan kredensial Google Cloud.

1. Buat project pada Google Cloud.
2. Aktifkan **Cloud Translation API** dan **Cloud Vision API**.
3. Buat service account dengan izin minimum untuk menggunakan kedua API tersebut.
4. Unduh service-account JSON dan simpan di server, bukan di APK atau repositori publik.
5. Masuk ke folder `backend`.
6. Jalankan `npm install`.
7. Salin `.env.example` menjadi `.env`, lalu isi:

```env
PORT=8787
GOOGLE_CLOUD_PROJECT=project-id-anda
GOOGLE_APPLICATION_CREDENTIALS=/path/aman/service-account.json
LINGUA_API_TOKEN=ganti-dengan-token-acak-panjang
MAX_IMAGE_BYTES=6500000
```

8. Jalankan backend saat pengembangan dengan `npm run dev`, atau build dan start dengan `npm run build` lalu `npm start`.
9. Publikasikan backend di alamat HTTPS. Jangan membuka port produksi tanpa HTTPS, rate limit, token, dan pembatasan biaya.
10. Uji `GET https://alamat-backend/health`. Respons yang diharapkan memuat `status: ok`.

Jika `LINGUA_API_TOKEN` diatur pada server, masukkan token yang sama pada aplikasi. Untuk produksi, gunakan token unik per pengguna/perangkat atau autentikasi yang lebih kuat. Token statis yang dimasukkan ke APK dapat diekstrak dan bukan mekanisme perlindungan kuat.

### Endpoint backend

- `GET /health`: status layanan.
- `POST /v1/translate-batch`: menerjemahkan kumpulan teks ke bahasa `id`.
- `POST /v1/ocr`: OCR cloud fallback. Endpoint ini menerima gambar layar yang dikirim oleh aplikasi.

Cloud OCR dinonaktifkan secara default pada aplikasi. Jika diaktifkan, gambar layar dapat dikirim ke server dan Google Cloud Vision. Hindari mengaktifkannya pada layar yang memuat data sensitif.

## B. Membuka dan membangun aplikasi Android

1. Instal Android Studio dan Android SDK Platform 35.
2. Instal JDK 17 atau gunakan JBR bawaan Android Studio.
3. Ekstrak folder project ini.
4. Buka folder `LINGUA-AI` sebagai project Android Studio.
5. Tunggu Gradle Sync dan unduh dependensi saat koneksi internet tersedia.
6. Pilih konfigurasi `app` dan perangkat Android atau emulator.
7. Jalankan aplikasi untuk pengujian.
8. Atau jalankan perintah berikut dari terminal project:

```bash
./gradlew :app:assembleDebug
```

Project menyertakan bootstrap wrapper ringan yang mengunduh Gradle 8.9 pada pemakaian pertama jika Gradle belum tersedia secara lokal. Karena itu, komputer yang membangun project harus memiliki Java dan koneksi internet untuk mengunduh Gradle serta dependensi Android.

APK debug akan dihasilkan pada:

```text
app/build/outputs/apk/debug/app-debug.apk
```

Untuk rilis:

```bash
./gradlew :app:assembleRelease
```

APK release perlu ditandatangani dengan signing key milik pemilik aplikasi sebelum didistribusikan.

## C. Konfigurasi di aplikasi

1. Buka LINGUA AI.
2. Masukkan URL backend HTTPS.
3. Masukkan access token jika backend mewajibkannya.
4. Tekan **SIMPAN KONFIGURASI**.
5. Aktifkan **OCR cloud fallback** hanya jika setuju gambar layar dikirim saat OCR lokal tidak menemukan teks.
6. Tekan **START TRANSLATION**.
7. Izinkan tampilan di atas aplikasi lain.
8. Izinkan notifikasi bila diminta.
9. Setujui dialog screen capture Android.
10. Buka aplikasi tujuan. LINGUA AI akan memeriksa perubahan layar dan memperbarui overlay.

Android meminta persetujuan screen capture setiap sesi. Notifikasi foreground service ditampilkan selama penerjemahan aktif. Gunakan tombol Stop pada aplikasi atau notifikasi untuk mengakhiri sesi.

## D. Cara kerja dan optimasi

- Frame diperiksa dengan interval awal 2,2 detik, dapat diatur pada preferensi internal 1,5–5 detik.
- Signature frame digunakan untuk melewati frame yang tidak berubah.
- Lima recognizer ML Kit dijalankan untuk Latin, Chinese, Japanese, Korean, dan Devanagari.
- Cloud Vision menjadi fallback ketika OCR lokal tidak menemukan teks dan pengguna mengaktifkannya.
- Language Identification berjalan per blok teks.
- Teks diterjemahkan secara batch dan hasilnya di-cache berdasarkan bahasa serta isi teks.
- Overlay memakai `FLAG_NOT_TOUCHABLE` agar tidak menghalangi interaksi aplikasi di bawahnya.
- Overlay memakai `FLAG_SECURE` untuk mencegah panel terjemahan ditangkap kembali sebagai input OCR.

## E. Batasan versi awal

1. Replace overlay adalah penutupan visual di atas tulisan asli, bukan pengubahan konten aplikasi sumber.
2. Posisi teks dapat sedikit bergeser pada perangkat dengan cutout, multi-window, perubahan resolusi, atau koordinat system bar yang berbeda. Perlu kalibrasi perangkat.
3. OCR lokal memiliki cakupan skrip yang ditentukan model ML Kit. Cloud OCR hanya menjadi fallback ketika hasil lokal kosong, sehingga teks campuran yang sebagian terbaca dapat tetap kehilangan fragmen tertentu.
4. Aplikasi yang menggunakan `FLAG_SECURE`, konten DRM, layar izin, atau layar sistem tertentu mungkin tidak dapat ditangkap.
5. Dialog game yang bergerak cepat, font dekoratif, teks vertikal, dan tulisan berkontras rendah dapat menurunkan akurasi.
6. Continuous capture dan beberapa recognizer OCR berdampak pada baterai. Uji interval, resolusi, dan perangkat nyata sebelum distribusi.
7. Beberapa produsen Android membatasi foreground service di latar belakang. Pengguna mungkin perlu mengatur battery optimization untuk penggunaan yang panjang.
8. API Translation dan Vision berbayar berdasarkan pemakaian. Pasang billing alert, quota, rate limit, dan batas biaya di Google Cloud.

## F. Checklist sebelum rilis publik

- [ ] Uji pada Android 8, 10, 13, 14, dan 15/16 sesuai perangkat yang tersedia.
- [ ] Uji rotasi portrait/landscape dan perangkat dengan cutout.
- [ ] Uji koordinat overlay terhadap OCR bounding box.
- [ ] Uji aplikasi yang menolak screen capture.
- [ ] Uji izin berhenti dan mulai ulang MediaProjection.
- [ ] Uji campuran bahasa pada satu layar.
- [ ] Uji kegagalan jaringan, timeout, dan retry.
- [ ] Uji pembatasan kuota serta biaya API.
- [ ] Lengkapi kebijakan privasi dan pengungkapan penggunaan screen capture.
- [ ] Buat signing key dan APK release.

## Catatan keamanan

Backend menyimpan kredensial Google Cloud di environment server. Jangan commit file `.env`, service account JSON, token produksi, atau screenshot pengguna. Aktifkan autentikasi, HTTPS, rate limiting, logging yang tidak merekam isi teks sensitif, serta pemantauan biaya.
