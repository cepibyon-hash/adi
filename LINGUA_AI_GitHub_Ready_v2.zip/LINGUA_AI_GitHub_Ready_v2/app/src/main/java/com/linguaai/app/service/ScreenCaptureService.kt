package com.linguaai.app.service

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.graphics.Bitmap
import android.graphics.PixelFormat
import android.hardware.display.DisplayManager
import android.hardware.display.VirtualDisplay
import android.media.ImageReader
import android.media.projection.MediaProjection
import android.media.projection.MediaProjectionManager
import android.os.Build
import android.os.Handler
import android.os.HandlerThread
import android.os.IBinder
import android.util.DisplayMetrics
import android.view.WindowManager
import androidx.core.app.NotificationCompat
import androidx.core.content.ContextCompat
import com.linguaai.app.MainActivity
import com.linguaai.app.R
import com.linguaai.app.data.AppPreferences
import com.linguaai.app.data.OverlayTranslation
import com.linguaai.app.data.TranslationApi
import com.linguaai.app.data.TranslationRequestItem
import com.linguaai.app.ocr.OcrEngine
import com.linguaai.app.overlay.TranslationOverlayController
import com.linguaai.app.util.BitmapUtils
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.launch
import java.security.MessageDigest
import java.util.LinkedHashMap
import java.util.concurrent.atomic.AtomicBoolean

class ScreenCaptureService : Service() {
    private lateinit var preferences: AppPreferences
    private lateinit var translationApi: TranslationApi
    private lateinit var ocrEngine: OcrEngine
    private lateinit var overlay: TranslationOverlayController
    private val serviceScope = CoroutineScope(SupervisorJob() + Dispatchers.IO)
    private var handlerThread: HandlerThread? = null
    private var captureHandler: Handler? = null
    private var mediaProjection: MediaProjection? = null
    private var virtualDisplay: VirtualDisplay? = null
    private var imageReader: ImageReader? = null
    private var lastCaptureAt = 0L
    private var lastFrameSignature = Long.MIN_VALUE
    private val processingFrame = AtomicBoolean(false)
    private var screenWidth = 1
    private var screenHeight = 1
    private var densityDpi = 1
    private val translationCache = object : LinkedHashMap<String, String>(256, 0.75f, true) {
        override fun removeEldestEntry(eldest: MutableMap.MutableEntry<String, String>?): Boolean = size > 350
    }

    private val projectionCallback = object : MediaProjection.Callback() {
        override fun onStop() {
            stopSelf()
        }
    }

    override fun onCreate() {
        super.onCreate()
        preferences = AppPreferences(this)
        translationApi = TranslationApi(preferences)
        ocrEngine = OcrEngine()
        overlay = TranslationOverlayController(this)
        handlerThread = HandlerThread("LinguaScreenCapture").also { it.start() }
        captureHandler = Handler(handlerThread!!.looper)
        createNotificationChannel()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == ACTION_STOP) {
            stopSelf()
            return START_NOT_STICKY
        }
        if (mediaProjection != null) return START_NOT_STICKY

        val notification = buildNotification()
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            startForeground(
                NOTIFICATION_ID,
                notification,
                ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION
            )
        } else {
            startForeground(NOTIFICATION_ID, notification)
        }

        val resultCode = intent?.getIntExtra(EXTRA_RESULT_CODE, 0) ?: 0
        @Suppress("DEPRECATION")
        val resultData: Intent? = if (Build.VERSION.SDK_INT >= 33) {
            intent?.getParcelableExtra(EXTRA_RESULT_DATA, Intent::class.java)
        } else {
            intent?.getParcelableExtra<Intent>(EXTRA_RESULT_DATA)
        }
        if (resultCode != android.app.Activity.RESULT_OK || resultData == null) {
            broadcastStatus(false, "Izin screen capture tidak diterima.")
            stopSelf()
            return START_NOT_STICKY
        }

        startProjection(resultCode, resultData)
        return START_NOT_STICKY
    }

    private fun startProjection(resultCode: Int, resultData: Intent) {
        try {
            val manager = getSystemService(Context.MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
            mediaProjection = manager.getMediaProjection(resultCode, resultData)
            mediaProjection?.registerCallback(projectionCallback, captureHandler)
            val metrics = DisplayMetrics()
            @Suppress("DEPRECATION")
            (getSystemService(Context.WINDOW_SERVICE) as WindowManager).defaultDisplay.getRealMetrics(metrics)
            screenWidth = metrics.widthPixels.coerceAtLeast(1)
            screenHeight = metrics.heightPixels.coerceAtLeast(1)
            densityDpi = metrics.densityDpi.coerceAtLeast(1)

            imageReader = ImageReader.newInstance(screenWidth, screenHeight, PixelFormat.RGBA_8888, 2)
            imageReader?.setOnImageAvailableListener({ reader -> onImageAvailable(reader) }, captureHandler)
            virtualDisplay = mediaProjection?.createVirtualDisplay(
                "LINGUA_AI_CAPTURE",
                screenWidth,
                screenHeight,
                densityDpi,
                DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR,
                imageReader?.surface,
                null,
                captureHandler
            )
            overlay.show()
            broadcastStatus(true, "LINGUA AI sedang menerjemahkan layar.")
        } catch (error: Exception) {
            broadcastStatus(false, "Gagal memulai screen capture: ${error.message ?: "kesalahan sistem"}")
            stopSelf()
        }
    }

    private fun onImageAvailable(reader: ImageReader) {
        val image = runCatching { reader.acquireLatestImage() }.getOrNull() ?: return
        val now = System.currentTimeMillis()
        if (now - lastCaptureAt < preferences.captureIntervalMs) {
            image.close()
            return
        }
        if (!processingFrame.compareAndSet(false, true)) {
            image.close()
            return
        }
        lastCaptureAt = now
        val bitmap = try {
            BitmapUtils.imageToBitmap(image)
        } catch (_: Exception) {
            null
        } finally {
            image.close()
        }
        if (bitmap == null) {
            processingFrame.set(false)
            return
        }

        val signature = runCatching { BitmapUtils.signature(bitmap) }.getOrDefault(Long.MIN_VALUE)
        if (signature == lastFrameSignature) {
            bitmap.recycle()
            processingFrame.set(false)
            return
        }
        lastFrameSignature = signature
        serviceScope.launch {
            try {
                processFrame(bitmap)
            } catch (cancelled: CancellationException) {
                throw cancelled
            } catch (error: Exception) {
                lastFrameSignature = Long.MIN_VALUE
                broadcastStatus(true, error.message ?: "Terjadi kesalahan saat menerjemahkan.")
            } finally {
                if (!bitmap.isRecycled) bitmap.recycle()
                processingFrame.set(false)
            }
        }
    }

    private suspend fun processFrame(bitmap: Bitmap) {
        val maxEdge = 1600
        val scale = maxEdge.toFloat() / maxOf(bitmap.width, bitmap.height).toFloat()
        val workingBitmap = if (scale < 1f) {
            Bitmap.createScaledBitmap(
                bitmap,
                (bitmap.width * scale).toInt().coerceAtLeast(1),
                (bitmap.height * scale).toInt().coerceAtLeast(1),
                true
            )
        } else bitmap

        try {
            var regions = ocrEngine.recognize(workingBitmap)
            val hasUsableLocalText = regions.any {
                it.text.trim().length >= 2 && it.bounds.width() > 3 && it.bounds.height() > 3
            }
            if (!hasUsableLocalText && preferences.cloudOcrEnabled) {
                regions = translationApi.cloudOcr(workingBitmap)
            }
            if (regions.isEmpty()) {
                overlay.clear()
                return
            }

            val validRegions = regions
                .filter { it.text.trim().length >= 2 && it.bounds.width() > 3 && it.bounds.height() > 3 }
                .take(45)
            if (validRegions.isEmpty()) {
                overlay.clear()
                return
            }

            val prepared = validRegions.map { region ->
                val language = ocrEngine.detectLanguage(region.text)
                Triple(region, language, cacheKey(region.text, language))
            }.filterNot { (_, language, _) -> language == "id" }
            if (prepared.isEmpty()) {
                overlay.clear()
                return
            }
            val missing = prepared.filter { (_, _, key) -> translationCache[key] == null }
            if (missing.isNotEmpty()) {
                val requests = missing.map { (region, language, _) ->
                    TranslationRequestItem(region.id, region.text, language)
                }
                val translated = translationApi.translateBatch(requests)
                missing.forEach { (region, _, key) ->
                    translated[region.id]?.let { translationCache[key] = it }
                }
            }

            val overlayItems = prepared.mapNotNull { (region, language, key) ->
                val translated = translationCache[key] ?: return@mapNotNull null
                OverlayTranslation(
                    id = region.id,
                    originalText = region.text,
                    translatedText = translated,
                    sourceLanguage = language,
                    bounds = region.bounds
                )
            }
            overlay.update(overlayItems, workingBitmap.width, workingBitmap.height)
            if (overlayItems.isNotEmpty()) broadcastStatus(true, "${overlayItems.size} bagian teks diterjemahkan.")
        } finally {
            if (workingBitmap !== bitmap && !workingBitmap.isRecycled) workingBitmap.recycle()
        }
    }

    private fun cacheKey(text: String, language: String): String {
        val normalized = "$language|${text.trim().lowercase().replace(Regex("\\s+"), " ")}"
        val bytes = MessageDigest.getInstance("SHA-256").digest(normalized.toByteArray())
        return bytes.joinToString("") { "%02x".format(it) }
    }

    private fun broadcastStatus(running: Boolean, message: String) {
        val update = Intent(ACTION_STATUS)
            .setPackage(packageName)
            .putExtra(EXTRA_RUNNING, running)
            .putExtra(EXTRA_MESSAGE, message)
        sendBroadcast(update)
    }

    private fun buildNotification(): Notification {
        val openIntent = PendingIntent.getActivity(
            this, 1, Intent(this, MainActivity::class.java),
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        val stopIntent = PendingIntent.getService(
            this, 2, Intent(this, ScreenCaptureService::class.java).setAction(ACTION_STOP),
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        return NotificationCompat.Builder(this, CHANNEL_ID)
            .setSmallIcon(R.drawable.ic_lingua)
            .setContentTitle("LINGUA AI aktif")
            .setContentText("Menerjemahkan layar ke Bahasa Indonesia")
            .setContentIntent(openIntent)
            .setOngoing(true)
            .setOnlyAlertOnce(true)
            .addAction(android.R.drawable.ic_media_pause, "Hentikan", stopIntent)
            .build()
    }

    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                CHANNEL_ID,
                "LINGUA AI Screen Translator",
                NotificationManager.IMPORTANCE_LOW
            ).apply {
                description = "Status layanan penerjemah layar LINGUA AI"
            }
            (getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager)
                .createNotificationChannel(channel)
        }
    }

    override fun onDestroy() {
        broadcastStatus(false, "Penerjemah layar dihentikan.")
        runCatching { virtualDisplay?.release() }
        runCatching { imageReader?.setOnImageAvailableListener(null, null) }
        runCatching { imageReader?.close() }
        runCatching { mediaProjection?.unregisterCallback(projectionCallback) }
        runCatching { mediaProjection?.stop() }
        overlay.hide()
        ocrEngine.close()
        serviceScope.cancel()
        handlerThread?.quitSafely()
        super.onDestroy()
    }

    override fun onBind(intent: Intent?): IBinder? = null

    companion object {
        const val ACTION_START = "com.linguaai.app.action.START"
        const val ACTION_STOP = "com.linguaai.app.action.STOP"
        const val ACTION_STATUS = "com.linguaai.app.action.STATUS"
        const val EXTRA_RESULT_CODE = "result_code"
        const val EXTRA_RESULT_DATA = "result_data"
        const val EXTRA_RUNNING = "running"
        const val EXTRA_MESSAGE = "message"
        private const val CHANNEL_ID = "lingua_screen_translation"
        private const val NOTIFICATION_ID = 701

        fun start(context: Context, resultCode: Int, data: Intent) {
            val intent = Intent(context, ScreenCaptureService::class.java)
                .setAction(ACTION_START)
                .putExtra(EXTRA_RESULT_CODE, resultCode)
                .putExtra(EXTRA_RESULT_DATA, data)
            ContextCompat.startForegroundService(context, intent)
        }

        fun stop(context: Context) {
            context.stopService(Intent(context, ScreenCaptureService::class.java))
        }
    }
}
